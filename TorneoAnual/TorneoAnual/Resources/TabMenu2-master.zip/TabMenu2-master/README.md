# TabMenu2
New TabMenu WPF and Material Design for my youtube channel http://youtube.com/designcomwpf

**CLONE OR DOWNLOAD**
* Open the file _TabMenu2.sln_ with Visual Studio
* Click right button on solution
* Chose the option: **Manage NuGet packages for solution...**
* In message: **"Some NuGet packages are missing from this solution. Click to restore from your online packages resources."**
* Click [Restore]
* Done, start the project!
